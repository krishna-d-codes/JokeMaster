package com.example.jokemaster;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface JokeApiService {

    // Example: https://v2.jokeapi.dev/joke/Any?lang=en
    @GET("joke/Any")
    Call<JokeResponse> getJoke(@Query("lang") String language);
}
