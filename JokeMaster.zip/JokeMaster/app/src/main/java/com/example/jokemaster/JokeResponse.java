package com.example.jokemaster;

public class JokeResponse {
    public boolean error;
    public String category;
    public String type;
    public String joke; // used when it's a single-line joke
    public String setup; // used for two-part jokes
    public String delivery; // used for two-part jokes
}
