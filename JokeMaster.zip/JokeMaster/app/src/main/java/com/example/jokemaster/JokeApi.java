package com.example.jokemaster;

import retrofit2.Call;


public class JokeApi {
    public Call<JokeResponse> getJoke(String langCode, String any) {
        return null;
    }

}
