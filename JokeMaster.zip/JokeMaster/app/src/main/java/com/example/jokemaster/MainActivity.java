package com.example.jokemaster;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView jokeTextView;
    Button btnGujarati, btnHindi, btnEnglish;

    // Offline joke arrays
    String[] hindiJokes = {
            "टीचर: बताओ सबसे ईमानदार कौन होता है?\nछात्र: मोबाइल… क्योंकि वो कभी भी चोरी छिपे नहीं बजता!",
            "पत्नी: सुनिए जी, सपना आया कि मैं हीरे की अंगूठी पहन रही हूँ, इसका क्या मतलब है?\nपति: यही कि सपना सपना ही होता है।",
            "सबसे ठंडा अल्फाबेट \"B\" है क्योकि यह A C के बीच रहता है",
            "स्त्री हार तभी स्वीकार करती है,\n" +
                    "जब हार सोने का हो...",
            "भगवान का दिया सबकुछ है, बस रखा कि धर पता नहा...\n",
            "कल बादाम भीगोये थे याददाश्त बढ़ाने के लिए अब याद ही नहीं आ रहा कि रखे कहा थे"


    };

    String[] gujaratiJokes = {
            "પપ્પા: પેપર કેમ ખરાબ ગયું?\nદીકરો: પ્રશ્નો જૂના હતા, અને હું તો નવો છું!",
            "શિક્ષક: તું ક્લાસમાં કેમ સુતેલો હતો?\nવિદ્યાર્થી: સાહેબ સ્વપ્નમાં ભણતો હતો!",
            "મમ્મી - લે જમી લે.\n" +
                    "શનીયો - હું એના વગર નઈ જમુ.\n" +
                    "મમ્મી - ( ચાર ઝાપટ મારી ને )\n" +
                    "કોણ છે એ ?\n" +
                    "શનીયો - અથાણું મમ્મી અથાણું !!!",
            "છોકરો: હાય, આઈ લવ યુ.\n" +
                    "છોકરી: મારે બોય ફ્રેન્ડ છે.\n" +
                    "છોકરો: વાંધો નય આટલું\n" +
                    "જાણવાના તારા બાપુજીએ, મને પાંચ હજાર દીધાં છે.",
            "અમુક નંગ એવા હોય જે \"હાલો હવે હુ રજા લવ છું\" કરતા કરતા કલાક સુધી ઊભા નો થાય......"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jokeTextView = findViewById(R.id.jokeTextView);
        btnGujarati = findViewById(R.id.btnGujarati);
        btnHindi = findViewById(R.id.btnHindi);
        btnEnglish = findViewById(R.id.btnEnglish);

        btnEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchJoke("en");
            }
        });

        btnHindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = (int) (Math.random() * hindiJokes.length);
                jokeTextView.setText(hindiJokes[index]);
            }
        });

        btnGujarati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = (int) (Math.random() * gujaratiJokes.length);
                jokeTextView.setText(gujaratiJokes[index]);
            }
        });
    }

    private void fetchJoke(String langCode) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Construct the URL
                    String apiUrl = "https://v2.jokeapi.dev/joke/Any?lang=" + langCode;
                    java.net.URL url = new java.net.URL(apiUrl);
                    java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();

                    int responseCode = connection.getResponseCode();

                    if (responseCode == 200) { // OK
                        java.io.InputStream inputStream = connection.getInputStream();
                        java.util.Scanner scanner = new java.util.Scanner(inputStream).useDelimiter("\\A");
                        String result = scanner.hasNext() ? scanner.next() : "";

                        // Parse the JSON response manually
                        org.json.JSONObject json = new org.json.JSONObject(result);
                        String type = json.getString("type");
                        String jokeText;

                        if (type.equals("single")) {
                            jokeText = json.getString("joke");
                        } else {
                            jokeText = json.getString("setup") + "\n" + json.getString("delivery");
                        }

                        // Update UI on the main thread
                        runOnUiThread(() -> jokeTextView.setText(jokeText));

                    } else {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "HTTP Error: " + responseCode, Toast.LENGTH_SHORT).show());
                    }

                    connection.disconnect();

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }
        }).start();
    }
}
